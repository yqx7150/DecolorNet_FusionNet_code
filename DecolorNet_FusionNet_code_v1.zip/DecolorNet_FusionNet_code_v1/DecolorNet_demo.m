%--------------------------------------------------------------------------------------------------------
%% The Code is created based on the method described in the following paper: 
% [1] Q. Liu, H. Leung.��Variable Augmented Neural Network for Decolorization and Multi-Exposure Fusion�� 
% Information Fusion, pp, 2018. 
% Author: Q. Liu, H. Leung 
% Date : 22/4/2017 
% Version : 1.0 
% The code and the algorithm are for non-comercial use only. 
% Copyright 2017, University of Calgary.
% The current version is not optimized. 

%% some codes were modified from the following references:
% The system is created based on the principles described in the following papers
% [1] Li Xu, Jimmy SJ. Ren, Qiong Yan, Renjie Liao, Jiaya Jia, "Deep Edge-Aware Filters",
% The 32nd International Conference on Machine Learning (ICML 2015). Lille, France, July 6-11, 2015
% [2] Jimmy SJ. Ren and Li Xu, "On Vectorization of Deep Convolutional Neural Networks for Vision Tasks",
% The 29th AAAI Conference on Artificial Intelligence (AAAI-15). Austin, Texas, USA, January 25-30, 2015
%--------------------------------------------------------------------------------------------------------

%% step1 add paths
addpath ./utils/
addpath ./cuda/
addpath ./mem/
addpath ./layers/
addpath ./layers_adapters/
addpath ./pipeline/

%% step2 config variables
clearvars -global config;
clearvars -global mem;
global config mem;
model_path = './results_Decolor_errorL1/epoc500.mat';
%model_path = './results_Decolor_errorL1_filtersize8_channel64/epoc199.mat';
beta = 8.388608e+03 / 2;  

%% step3 main code
I0 = im2double(imread('750px-Paul_ne_112.jpg'));    
I = padarray(I0,[8 8 0],'symmetric');   
fprintf('preparing the network...\n');
prepare_net_filter_liu(size(I, 1), size(I, 2), model_path);
fprintf('filtering the image...\n');
S = I;
h_input = [diff(S,1,2), S(:,1,:) - S(:,end,:)];v_input = [diff(S,1,1); S(1,:,:) - S(end,:,:)];
h_input = h_input * 2;v_input = v_input * 2;
v_input = config.NEW_MEM(v_input);h_input = config.NEW_MEM(h_input);
out = apply_net_filter(v_input, h_input); 
v = out(:,:,:,1);h = out(:,:,:,2);
v = v / 2;h = h / 2;
h(:, end, :) = S(:,1,:) - S(:,end,:);v(end, :, :) = S(1,:,:) - S(end,:,:);
S = repmat(GcsDecolor2(I,0.1),[1,1,3]);  
filtered = grad_process(S, v, h, beta);  
filtered = filtered(8+1:end-8, 8+1:end-8, :);

%% step4 display result
patch_filtered = mean(filtered,3); 
patch_filteredGcs = GcsDecolor2(I0,0.1); 
patch_rgb2gray = rgb2gray(I0); 
figure(20);imshow([patch_rgb2gray, patch_filtered, patch_filteredGcs]); drawnow();
