%--------------------------------------------------------------------------------------------------------
%% The Code is created based on the method described in the following paper: 
% [1] Q. Liu, H. Leung.��Variable Augmented Neural Network for Decolorization and Multi-Exposure Fusion�� 
% Information Fusion, pp, 2018. 
% Author: Q. Liu, H. Leung 
% Date : 22/4/2017 
% Version : 1.0 
% The code and the algorithm are for non-comercial use only. 
% Copyright 2017, University of Calgary.
% The current version is not optimized. 

%% some codes were modified from the following references:
% The system is created based on the principles described in the following papers
% [1] Li Xu, Jimmy SJ. Ren, Qiong Yan, Renjie Liao, Jiaya Jia, "Deep Edge-Aware Filters",
% The 32nd International Conference on Machine Learning (ICML 2015). Lille, France, July 6-11, 2015
% [2] Jimmy SJ. Ren and Li Xu, "On Vectorization of Deep Convolutional Neural Networks for Vision Tasks",
% The 29th AAAI Conference on Artificial Intelligence (AAAI-15). Austin, Texas, USA, January 25-30, 2015
%--------------------------------------------------------------------------------------------------------

%% step1 add paths
addpath ./utils/
addpath ./cuda/
addpath ./mem/
addpath ./layers/
addpath ./layers_adapters/
addpath ./pipeline/

%% step2 config variables
clearvars -global config;
clearvars -global mem;
global config mem;
I221 = im2double(imread('./Landscape_HDRsoft/landscape_normal.png'));
[size1,size2,size3] = size(I221);
I = zeros(size1,size2*3,3); 
I(:,1:size2,1) = I221(:,1:size2,1);I(:,size2+1:size2+size2,1) = I221(:,1:size2,2);I(:,2*size2+1:2*size2+size2,1) = I221(:,1:size2,3);
I221_Avr = I221;
I221 = im2double(imread('./Landscape_HDRsoft/landscape_over.png'));
I(:,1:size2,2) = I221(:,1:size2,1);I(:,size2+1:size2+size2,2) = I221(:,1:size2,2);I(:,2*size2+1:2*size2+size2,2) = I221(:,1:size2,3);
I221_Avr = I221_Avr + I221;
I221 = im2double(imread('./Landscape_HDRsoft/landscape_under.png'));
I(:,1:size2,3) = I221(:,1:size2,1);I(:,size2+1:size2+size2,3) = I221(:,1:size2,2);I(:,2*size2+1:2*size2+size2,3) = I221(:,1:size2,3);
I221_Avr = I221_Avr + I221;

%% step3 main code
I = padarray(I,[8 8 0],'symmetric');   
model_path = './results_Fusion_L1/epoc8.mat';
beta = 8.388608e+02 / 2;   
fprintf('preparing the network...\n');
prepare_net_filter_liu(size(I, 1), size(I, 2), model_path);
fprintf('filtering the image...\n');
S = I;
h_input = [diff(S,1,2), S(:,1,:) - S(:,end,:)];
v_input = [diff(S,1,1); S(1,:,:) - S(end,:,:)];
h_input = h_input * 2;
v_input = v_input * 2;
v_input = config.NEW_MEM(v_input);
h_input = config.NEW_MEM(h_input);
out = apply_net_filter(v_input, h_input);
v = out(:,:,:,1);
h = out(:,:,:,2);
v = v / 2;
h = h / 2;
h(:, end, :) = S(:,1,:) - S(:,end,:);
v(end, :, :) = S(1,:,:) - S(end,:,:);
S = repmat(mean(I,3),[1,1,3]);    
filtered = grad_process(S, v, h, beta);

%% step4 display result
patch_filtered = mean(filtered,3); 
patch_filtered = patch_filtered(8+1:end-8, 8+1:end-8, :);
S = S(8+1:end-8, 8+1:end-8, :);
I221_Net(:,1:size2,1) = patch_filtered(:,1:size2,1);
I221_Net(:,1:size2,2) = patch_filtered(:,size2+1:size2+size2,1);
I221_Net(:,1:size2,3) = patch_filtered(:,2*size2+1:2*size2+size2,1);
I221_Mean(:,1:size2,1) = S(:,1:size2,1);
I221_Mean(:,1:size2,2) = S(:,size2+1:size2+size2,1);
I221_Mean(:,1:size2,3) = S(:,2*size2+1:2*size2+size2,1);
figure(22224);imshow([I221_Mean, I221_Net(:,1:size2,:)]); drawnow();

