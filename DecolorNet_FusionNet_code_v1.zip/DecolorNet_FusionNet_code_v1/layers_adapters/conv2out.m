function conv2out()
    % currently not implemented    
end

