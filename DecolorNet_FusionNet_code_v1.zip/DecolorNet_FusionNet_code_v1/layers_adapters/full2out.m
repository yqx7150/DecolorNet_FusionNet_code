function full2out()
    % currently not implemented
end

