function full_mem(layer_idx)
    global mem;
    
    
end