function sigm = nonlinearity_nil(x)
    sigm = x;
end
