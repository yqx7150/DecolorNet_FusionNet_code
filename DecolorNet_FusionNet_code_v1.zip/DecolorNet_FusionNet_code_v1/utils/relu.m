function out = relu(x)
    out = max(0, x);
end

