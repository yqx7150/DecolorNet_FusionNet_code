function y = scale_input_nil(x)
    y = x;
end