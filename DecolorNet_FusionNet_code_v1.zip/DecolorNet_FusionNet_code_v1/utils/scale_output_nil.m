function scale_output_nil()
    % nothing here
end

