function xx = to_cpu(x)
    xx = single(x);
end